package interface_compilador;

import java.util.Stack;

public class Sintatico implements Constants {
    private Stack stack = new Stack();
    private Token currentToken;
    private Token previousToken;
    private Lexico scanner;
    private Semantico semanticAnalyser;
    private boolean emDeclaracaoComAtribuicao = false;

    private static final boolean isTerminal(int x) {
        return x < FIRST_NON_TERMINAL;
    }

    private static final boolean isNonTerminal(int x) {
        return x >= FIRST_NON_TERMINAL && x < FIRST_SEMANTIC_ACTION;
    }

    private static final boolean isSemanticAction(int x) {
        return x >= FIRST_SEMANTIC_ACTION;
    }

    private boolean step() throws LexicalError, SyntaticError, SemanticError {
        if (currentToken == null) {
            int pos = 0;
            if (previousToken != null)
                pos = previousToken.getPosition() + previousToken.getLexeme().length();
            currentToken = new Token(DOLLAR, "$", pos);
        }

        int x = ((Integer) stack.pop()).intValue();
        int a = currentToken.getId();

        if (x == EPSILON) {
            return false;
        } else if (isTerminal(x)) {
            if (x == a) {
                if (stack.empty())
                    return true;
                else {
                    previousToken = currentToken;
                    currentToken = scanner.nextToken();
                    return false;
                }
            } else {
                String tokenEncontrado = formatarTokenEncontrado(currentToken);
                String simbolosEsperados = obterSimbolosEsperadosTerminal(x);

                throw new SyntaticError("encontrado " + tokenEncontrado + " esperado " + simbolosEsperados,
                        currentToken.getPosition());
            }
        } else if (isNonTerminal(x)) {
            if (pushProduction(x, a))
                return false;
            else {
                String tokenEncontrado = formatarTokenEncontrado(currentToken);
                String simbolosEsperados = obterSimbolosEsperadosNaoTerminal(x, a);

                throw new SyntaticError("encontrado " + tokenEncontrado + " esperado " + simbolosEsperados,
                        currentToken.getPosition());
            }
        } else {
            semanticAnalyser.executeAction(x - FIRST_SEMANTIC_ACTION, previousToken);
            return false;
        }
    }

    private String formatarTokenEncontrado(Token token) {
        if (token == null)
            return "EOF";

        int tokenId = token.getId();
        String lexeme = token.getLexeme();

        switch (tokenId) {
            case DOLLAR:
                return "EOF";
            case t_Const_string:
                return "constante_string";
            case t_Const_int:
                return "constante_int";
            case t_Const_float:
                return "constante_float";
            case t_id:
                return lexeme;
            case t_pr_tipoInt:
                return "int";
            case t_pr_tipoFloat:
                return "float";
            case t_pr_tipoString:
                return "string";
            case t_pr_tipoBoolean:
                return "bool";
            case t_pr_list:
                return "list";
            case t_pr_begin:
                return "begin";
            case t_pr_end:
                return "end";
            case t_pr_if:
                return "if";
            case t_pr_else:
                return "else";
            case t_pr_do:
                return "do";
            case t_pr_until:
                return "until";
            case t_pr_read:
                return "read";
            case t_pr_print:
                return "print";
            case t_pr_add:
                return "add";
            case t_pr_delete:
                return "delete";
            case t_pr_and:
                return "and";
            case t_pr_or:
                return "or";
            case t_pr_not:
                return "not";
            case t_pr_true:
                return "true";
            case t_pr_false:
                return "false";
            case t_TOKEN_3:
                return "+";
            case t_TOKEN_32:
                return "<-";
            case t_TOKEN_33:
                return "=";
            case t_TOKEN_34:
                return ",";
            case t_TOKEN_35:
                return ")";
            case t_TOKEN_36:
                return "(";
            case t_TOKEN_37:
                return ";";
            case t_TOKEN_38:
                return "==";
            case t_TOKEN_39:
                return "<";
            case t_TOKEN_40:
                return ">";
            case t_TOKEN_41:
                return "-";
            case t_TOKEN_42:
                return "*";
            case t_TOKEN_43:
                return "/";
            default:
                return lexeme;
        }
    }

    private String obterSimbolosEsperadosTerminal(int terminal) {
        if (terminal == t_TOKEN_34) { 
            return ", )";
        }

        if (terminal == t_TOKEN_37) { 
            if (currentToken != null && currentToken.getId() == t_TOKEN_33) {
                return "expressao";
            }
        }

        switch (terminal) {
            case DOLLAR:
                return "EOF";
            case t_id:
                return "identificador";
            case t_Const_int:
                return "constante_int";
            case t_Const_float:
                return "constante_float";
            case t_Const_string:
                return "constante_string";
            case t_pr_tipoInt:
            case t_pr_tipoFloat:
            case t_pr_tipoString:
            case t_pr_tipoBoolean:
            case t_pr_list:
                return "tipo";
            case t_TOKEN_3:
                return "+";
            case t_TOKEN_32:
                return "<-";
            case t_TOKEN_33:
                return "=";
            case t_TOKEN_34:
                return ","; 
            case t_TOKEN_35:
                return ")";
            case t_TOKEN_36:
                return "(";
            case t_TOKEN_37:
                return ";"; 
            case t_TOKEN_38:
                return "==";
            case t_TOKEN_39:
                return "<";
            case t_TOKEN_40:
                return ">";
            case t_TOKEN_41:
                return "-";
            case t_TOKEN_42:
                return "*";
            case t_TOKEN_43:
                return "/";
            case t_pr_begin:
                return "begin";
            case t_pr_end:
                return "end";
            case t_pr_if:
                return "if";
            case t_pr_else:
                return "else";
            case t_pr_do:
                return "do";
            case t_pr_until:
                return "until";
            case t_pr_read:
                return "read";
            case t_pr_print:
                return "print";
            case t_pr_add:
                return "add";
            case t_pr_delete:
                return "delete";
            case t_pr_and:
                return "and";
            case t_pr_or:
                return "or";
            case t_pr_not:
                return "not";
            case t_pr_true:
                return "true";
            case t_pr_false:
                return "false";
            default:
                return PARSER_ERROR[terminal].replace("Era esperado", "").trim();
        }
    }

    private String obterSimbolosEsperadosNaoTerminal(int naoTerminal, int tokenAtual) {

        if (naoTerminal == 45 && tokenAtual == t_pr_end) {
            return "";
        }

        if (naoTerminal == 57 && isTokenComando(tokenAtual)) {
            return ", )";
        }

        if (naoTerminal == 85 && (tokenAtual == t_pr_end || tokenAtual == DOLLAR)) {
            return ")";
        }

        if (naoTerminal == 56 && tokenAtual == DOLLAR) {
            return "identificador do if print read tipo";
        }

        if (naoTerminal == 56 && tokenAtual == t_TOKEN_33) {
            return "expressao";
        }

        if (naoTerminal == 63) {
            return ", )";
        }

        if ((naoTerminal == 58 || naoTerminal == 70 || naoTerminal == 68) &&
                (tokenAtual == t_pr_end || tokenAtual == DOLLAR)) {
            return ")";
        }

        String resultado = PARSER_ERROR[naoTerminal];
        return resultado;
    }

    private boolean isTokenComando(int token) {
        return token == t_pr_print || token == t_pr_read || token == t_pr_if ||
                token == t_pr_do || token == t_pr_else || token == t_pr_end;
    }

    private boolean pushProduction(int topStack, int tokenInput) {
        int p = PARSER_TABLE[topStack - FIRST_NON_TERMINAL][tokenInput - 1];

        if (topStack == 45 && tokenInput == t_pr_end) {
            stack.push(new Integer(EPSILON));
            return true;
        }

        if (p >= 0) {
            int[] production = PRODUCTIONS[p];
            for (int i = production.length - 1; i >= 0; i--) {
                stack.push(new Integer(production[i]));
            }
            return true;
        } else {
            return false;
        }
    }

    public void parse(Lexico scanner, Semantico semanticAnalyser) throws LexicalError, SyntaticError, SemanticError {
        this.scanner = scanner;
        this.semanticAnalyser = semanticAnalyser;

        stack.clear();
        stack.push(new Integer(DOLLAR));
        stack.push(new Integer(START_SYMBOL));

        currentToken = scanner.nextToken();

        while (!step()) {
        }
    }

    private boolean isNaoTerminalExpressao(int naoTerminal) {
        return naoTerminal == 66 ||  
                naoTerminal == 77 || 
                naoTerminal == 78 || 
                naoTerminal == 79 || 
                naoTerminal == 80 || 
                naoTerminal == 81 || 
                naoTerminal == 82 || 
                naoTerminal == 83 || 
                naoTerminal == 84 || 
                naoTerminal == 85; 
    }

    private boolean isTokenInicioExpressao(int token) {
        return token == t_id ||
                token == t_Const_int ||
                token == t_Const_float ||
                token == t_Const_string ||
                token == t_pr_true ||
                token == t_pr_false ||
                token == t_TOKEN_36 || 
                token == t_pr_not ||
                token == t_TOKEN_41; 
    }

    private boolean isNaoTerminalQueEsperaFechamento(int naoTerminal) {
        return naoTerminal == 58 || 
                naoTerminal == 68 ||
                naoTerminal == 70 ||
                naoTerminal == 66 ||
                naoTerminal == 79; 
    }

    private boolean isNaoTerminalLista(int naoTerminal) {
        return naoTerminal == 58 || 
                naoTerminal == 68 || 
                naoTerminal == 70 || 
                naoTerminal == 45 || 
                naoTerminal == 52 ||
                naoTerminal == 72;
    }
}