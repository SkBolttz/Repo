package interface_compilador;

public class TesteEspecificacoesMensagens {
    public static void main(String[] args) {
        Lexico lexico = new Lexico();
        Sintatico sintatico = new Sintatico();
        Semantico semantico = new Semantico();

        System.out.println("🧪 TESTE DE ESPECIFICAÇÕES DE MENSAGENS\n");

        String[][] testes = {
            {"Constante_string na mensagem", "begin\nprint(\"olá mundo)\nend", "constante_string"},
            
            {"EOF na mensagem", "begin\nint x", "EOF"},
            
            {"Lexema do identificador", "begin\narea = 5\nend", "area"},
            
            {"Lexema da constante_int", "begin\nx = 123\nend", "123"},
            
            {"Lexema do símbolo", "begin\nx = 5 ; y = 10\nend", ";"},
            
            {"Esperado EOF", "begin end x", "esperado EOF"},
            
            {"Esperado identificador", "begin\nint 123\nend", "esperado identificador"},
            
            {"Esperado constante_int", "begin\nx = abc\nend", "esperado constante_int"},
            
            {"Esperado constante_float", "begin\nfloat x = abc\nend", "esperado constante_float"},
            
            {"Esperado constante_string", "begin\nprint(abc)\nend", "esperado constante_string"},
            
            {"Esperado tipo", "begin\nxyz\nend", "esperado tipo"},
            
            {"Esperado int específico", "begin\nfloat = 5\nend", "esperado int"},
            
            {"Esperado float específico", "begin\nint = 5.5\nend", "esperado float"},
            
            {"Esperado bool específico", "begin\nstring = true\nend", "esperado bool"},
            
            {"Esperado string específico", "begin\nbool = \"texto\"\nend", "esperado string"},
            
            {"Esperado list específico", "begin\nint = list\nend", "esperado list"},
            
            {"Palavra reservada if", "begin\niff (x) end\nend", "esperado if"},
            
            {"Símbolo especial =", "begin\nx == 5\nend", "esperado ="},
            
            {"Não-terminal lista_expressoes", "begin\nprint()\nend", "esperado expressao"},
            
            {"Não-terminal expressao", "begin\nx = \nend", "esperado expressao"},
            
            {"Não-terminal valor/relacional", "begin\nif () end\nend", "esperado expressao"},
            
            {"Outro não-terminal", "begin\nread x\nend", "esperado ("}
        };

        int acertos = 0;
        
        for (String[] teste : testes) {
            System.out.println("🔍 " + teste[0]);
            System.out.println("   Código: " + teste[1].replace("\n", "\\n"));
            
            lexico.setInput(teste[1]);
            try {
                sintatico.parse(lexico, semantico);
                System.out.println("   ❌ FALHOU: Não gerou erro");
            } catch (SyntaticError e) {
                String mensagem = e.getMessage();
                boolean valido = mensagem.contains(teste[2]);
                
                System.out.println("   Mensagem: " + mensagem);
                System.out.println("   Esperado: " + teste[2] + "");
                
                if (valido) {
                    System.out.println("   ✅ CORRETO");
                    acertos++;
                } else {
                    System.out.println("   ❌ INCORRETO");
                }
            } catch (Exception e) {
                System.out.println("   💥 ERRO: " + e.getMessage());
            }
            System.out.println();
        }

        System.out.println("📊 RESULTADO: " + acertos + "/" + testes.length + " especificações atendidas");
        
        if (acertos == testes.length) {
            System.out.println("🎉 TODAS AS ESPECIFICAÇÕES ESTÃO CORRETAS!");
        } else {
            System.out.println("⚠️  " + (testes.length - acertos) + " especificações precisam de ajuste");
        }
    }
}